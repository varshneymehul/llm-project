from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse, StreamingHttpResponse
from rest_framework.response import Response
from langchain_google_genai import ChatGoogleGenerativeAI

from rest_framework.decorators import (
    api_view,
    authentication_classes,
    permission_classes,
)
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.authentication import JWTAuthentication
import time

import os
from dotenv import load_dotenv

load_dotenv()
api_key = os.getenv("API_KEY")

from langchain_core.prompts import PromptTemplate

prompt = PromptTemplate(
    input_variables=["chat_history", "input"],
    template="""
    You are a chatbot having a conversation with a human.

    Conversation so far:
    {chat_history}
    Human: {input}
    Chatbot:
    """,
)
from langchain.memory import ConversationBufferMemory
from langchain.prompts import PromptTemplate

memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)

llm = ChatGoogleGenerativeAI(model="models/gemini-1.5-flash", api_key=api_key)

from langchain.chains import ConversationChain

conversation = ConversationChain(llm=llm, verbose=True, memory=memory, prompt=prompt)


@api_view(["POST"])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def ask_llm(request):
    user_question = request.data.get("question", "")
    if not user_question:
        return Response({"error": "No question provided"}, status=400)

    def stream_response():
        response = conversation.predict(input=user_question)

        print(response)
        for word in response.split():
            yield word + " "
            time.sleep(0.03)  # small delay for smoother frontend streaming

    return StreamingHttpResponse(stream_response(), content_type="text/plain")


def hello_world(request):
    return JsonResponse({"message": "Hello World"})
