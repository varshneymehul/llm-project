from django.urls import path
from .views import hello_world,ask_llm

urlpatterns = [
    path("hello/", hello_world),
    path("ask/", ask_llm),  # new LLM endpoint
]
